package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;

public class LeadsPage extends ProjectSpecificMethod{
	
	/*
	 * public LeadsPage(ChromeDriver driver) { this.driver=driver; }
	 */
	public CreateLeadPage clickcreateLead() throws IOException {
		try {
			getDriver().findElement(By.linkText("Create Lead")).click();
			reportStep("pass", "CreaLead is clicked successfully");
		} catch (IOException e) {
			reportStep("fail", "CreateLead is not clicked successfully");
		}
		return new CreateLeadPage();
	}
	
	
	
	public Findleads clickfindsLead() {
		getDriver().findElement(By.linkText("Create Lead")).click();
		return new Findleads();
	}
	
	

}

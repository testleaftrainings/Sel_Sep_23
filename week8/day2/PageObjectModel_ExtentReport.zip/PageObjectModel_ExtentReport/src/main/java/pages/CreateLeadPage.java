package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;

public class CreateLeadPage extends ProjectSpecificMethod {

	/*
	 * public CreateLeadPage(ChromeDriver driver) { this.driver = driver; }
	 */
	public CreateLeadPage enterCompanyName(String cname) throws IOException {
		try {
			getDriver().findElement(By.id("createLeadForm_companyName")).sendKeys(cname);
			reportStep("pass", "Entered the companyName "+cname+" successfully");
		} catch (IOException e) {
			reportStep("fail", "Companyname "+cname+" is not entered successfully");
		}
		return this;
	}

	public CreateLeadPage enterFirstName(String fname) throws IOException {
		try {
			getDriver().findElement(By.id("createLeadForm_firstName")).sendKeys(fname);
			reportStep("pass", "Entered the firstName "+fname+" successfully");

		} catch (Exception e) {
			
			reportStep("fail", "Entered the firstName "+fname+" is not successful");
		}
		return this;
	}

	public CreateLeadPage enterLastName(String lname) throws IOException {
		try {
			getDriver().findElement(By.id("createLeadForm_lastName")).sendKeys(lname);
			reportStep("pass", "Entered the lastName "+lname+" successfully");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			reportStep("fail", "Entered the lastName "+lname+" is not successful");
		}

		return this;
	}

	public ViewLeadPages clickCreate() throws IOException {
		try {
			getDriver().findElement(By.name("submitButton")).click();
			reportStep("pass", "Submit button is clicked successful");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			reportStep("fail", "Submit button is not clicked successful");
		}
		return new ViewLeadPages();
	}

}

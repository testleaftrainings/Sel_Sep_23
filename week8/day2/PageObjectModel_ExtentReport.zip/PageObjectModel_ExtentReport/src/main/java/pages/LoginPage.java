package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ConfigurationManager;
import base.ProjectSpecificMethod;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class LoginPage extends ProjectSpecificMethod {

	/*
	 * public LoginPage(ChromeDriver driver) { this.driver=driver; }
	 */

	@Given("Enter the username")
	public LoginPage enterUsername() throws IOException {

		try {
			getDriver().findElement(By.id("username")).sendKeys(ConfigurationManager.configuration().getUserName());
			reportStep("pass", "Username is entered successfully");
		} catch (IOException e) {
			reportStep("fail", "Username is not entered successfully");
		}

		return this;

	}

	@Given("Enter the password")
	public LoginPage enterPassword() throws IOException {
		try {
			String password = ConfigurationManager.configuration().getPassword();
			getDriver().findElement(By.id("password")).sendKeys(password);
			reportStep("pass", "Password is entered successfully");
		} catch (IOException e) {
			reportStep("fail", "Password is not entered successfully");
		}
		return this;

	}

	@When("Click on Login button")
	public WelcomePage clickLogin() throws IOException {
		
		try {
			getDriver().findElement(By.className("decorativeSubmit")).click();
			reportStep("pass", "Login is clicked successfully");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			reportStep("fail", "Login is not clicked successfully");
		}
		return new WelcomePage();

	}

}

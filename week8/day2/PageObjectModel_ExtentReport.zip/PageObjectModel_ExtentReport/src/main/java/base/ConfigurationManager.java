package base;


import org.aeonbits.owner.ConfigCache;

public class ConfigurationManager {
   
    public static Configuration configuration() {
             Configuration orCreate = ConfigCache.getOrCreate(Configuration.class);
             return orCreate;
    }
    //creating instance for the Configuration(interface)



}

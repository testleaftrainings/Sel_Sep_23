package base;

public class LearnExceptionHandling {

	public static void main(String[] args) {
	
		int x=10;
		int y=2;
		int [] arr= {1,2,3,4,5};
		String s=null;
		try {
			System.out.println(x/y);
			System.out.println(arr[2]);
			try {
			System.out.println(s.length());
			}catch(Exception e) {
				if(!s.isEmpty()) {
					System.out.println(s.length());
			}else {
				s="Testleaf";
				System.out.println(s.length());
			}
				}
		}catch (ArithmeticException e) {
			System.out.println(e);
		}catch (ArrayIndexOutOfBoundsException e) {
			System.out.println(e);
		}
		System.out.println("End of program");
		

	}

}

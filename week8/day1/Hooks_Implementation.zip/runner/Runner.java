package runner;


import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import stepsdef.Baseclass;


@CucumberOptions(features= {"src/test/java/feature/Login.feature"}
                  ,glue="stepsdef",monochrome=true,
                		 // tags="@Deepa" //at feature level
                		 // tags="@sanity" //scenario with @sanity will be executed
                		  //tags="not @sanity" //exclude the scenario from execution
                		//  tags="@Funtional and @sanity" //to execute the scenario with both the given tags are present
                		     tags="@Funtional or @sanity"
		)
public class Runner extends Baseclass{
	
}


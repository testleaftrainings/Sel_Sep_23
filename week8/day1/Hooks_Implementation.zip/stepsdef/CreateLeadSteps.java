package stepsdef;

import org.openqa.selenium.By;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class CreateLeadSteps extends Baseclass{
	
	

	@When("Click on {string} link")
	public void click_on_crmsfa_link(String links) {
		driver.findElement(By.linkText(links)).click();
	}

	
	@When("Enter the {string} as {string}")
	public void enterMandatoryFields(String locator,String cname) {
		driver.findElement(By.id(locator)).sendKeys(cname);

	}
	
	
	@When("Click on CreateLead button")
	public void click_on_create_lead_button() {
		driver.findElement(By.name("submitButton")).click();
	}

	@Then("ViewLeadPage is displayed")
	public void view_lead_page_is_displayed() {
		System.out.println(driver.getTitle());
	}
	
}

package stepsdef;

import java.time.Duration;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.testng.AbstractTestNGCucumberTests;

public class Baseclass extends  AbstractTestNGCucumberTests {
	public  static ChromeDriver driver;
	
	//@Before //cucumber annotation to execute the method before each scenario
	@BeforeMethod
	public void preCondition() {		
		driver =new ChromeDriver();
		driver.get("http://leaftaps.com/opentaps/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	}
	
	
	//@After //to  execute the methods after each scenario
	@AfterMethod
	public void postCondition() {		
		driver.close();
	}
}

package stepsdef;

import java.time.Duration;

import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.After;
import io.cucumber.java.Before;

public class HooksImplemetation extends Baseclass {

	/*
	 * // public ChromeDriver driver;
	 * 
	 * @Before //cucumber annotation to execute the method before each scenario
	 * public void preCondition() { driver =new ChromeDriver();
	 * driver.get("http://leaftaps.com/opentaps/");
	 * driver.manage().window().maximize();
	 * driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10)); }
	 * 
	 * 
	 * @After //to execute the methods after each scenario public void
	 * postCondition() { driver.close(); }
	 * 
	 */}

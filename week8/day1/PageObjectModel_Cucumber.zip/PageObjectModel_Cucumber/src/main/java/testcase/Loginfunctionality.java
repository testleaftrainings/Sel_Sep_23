package testcase;

import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;
import pages.WelcomePage;

public class Loginfunctionality extends ProjectSpecificMethod{
	
	
		
	@Test
	public void runLogin() {
				
		System.out.println(getDriver() +"for the thread value" +Thread.currentThread().getId());

		/*
		 * LoginPage lp=new LoginPage(); lp.enterUsername(); lp.enterPassword();
		 * 
		 * 
		 * WelcomePage wp= new WelcomePage(); wp.clickCrmsfa();
		 */
		
		new LoginPage().enterUsername().enterPassword().clickLogin().clickCrmsfa();
		
	}

}

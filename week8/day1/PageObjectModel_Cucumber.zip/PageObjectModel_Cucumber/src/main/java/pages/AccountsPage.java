package pages;

public class AccountsPage {

}

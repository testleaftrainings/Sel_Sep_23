package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;
import io.cucumber.java.en.Then;

public class WelcomePage extends ProjectSpecificMethod {
	/*
	 * public WelcomePage(ChromeDriver driver) { this.driver = driver; }
	 */

	@Then("WelcomePage is displayed")
	public WelcomePage verifyWelcomePage() {
		System.out.println(getDriver().getTitle());
		return this;
	}

	public MyHomePage clickCrmsfa() {

		getDriver().findElement(By.linkText("CRM/SFA")).click();
		return new MyHomePage();
	}

	public LoginPage clickLogout() {
		getDriver().findElement(By.className("decorativeSubmit")).click();
		return new LoginPage();
	}

}

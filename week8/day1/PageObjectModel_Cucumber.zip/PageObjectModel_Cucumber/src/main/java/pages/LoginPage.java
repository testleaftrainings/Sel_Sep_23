package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class LoginPage extends ProjectSpecificMethod{
	
	
	/*
	 * public LoginPage(ChromeDriver driver) { this.driver=driver; }
	 */

	@Given("Enter the username")
	public LoginPage enterUsername() {	
		getDriver().findElement(By.id("username")).sendKeys("DemoCSR");
		return this;
		
	}

	@Given("Enter the password")
	public LoginPage enterPassword() {
		getDriver().findElement(By.id("password")).sendKeys("crmsfa");
		return this;

	}

	@When("Click on Login button")
	public WelcomePage clickLogin() {
		getDriver().findElement(By.className("decorativeSubmit")).click();
		return new WelcomePage();

	}

}

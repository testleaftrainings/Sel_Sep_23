package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;

public class MyHomePage extends ProjectSpecificMethod{
	
	/*
	 * public MyHomePage() { this.driver=driver; }
	 */
	public LeadsPage clickLeads() {
		getDriver().findElement(By.linkText("Leads")).click();
		return new LeadsPage();
	}
	
	/*
	 * public AccountsPage clickAccounts() {
	 * driver.findElement(By.linkText("Leads")).click(); return new AccountsPage();
	 * }
	 */

}
